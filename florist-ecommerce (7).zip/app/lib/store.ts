export interface Product {
  id: number
  name: string
  description: string
  price: number
  image: string
  categoryId: number
}

export interface Category {
  id: number
  name: string
}

const products: Product[] = [
  {
    id: 1,
    name: "Spring Bouquet",
    description: "A beautiful bouquet of spring flowers",
    price: 49.99,
    image: "/placeholder.svg",
    categoryId: 1,
  },
  {
    id: 2,
    name: "Rose Arrangement",
    description: "An elegant arrangement of premium roses",
    price: 59.99,
    image: "/placeholder.svg",
    categoryId: 2,
  },
  {
    id: 3,
    name: "Tulip Collection",
    description: "A colorful collection of fresh tulips",
    price: 39.99,
    image: "/placeholder.svg",
    categoryId: 1,
  },
]

const categories: Category[] = [
  { id: 1, name: "Bouquets" },
  { id: 2, name: "Arrangements" },
  { id: 3, name: "Single Flowers" },
  { id: 4, name: "Plants" },
]

export const getProducts = () => products
export const getProduct = (id: number) => products.find((p) => p.id === id)
export const getCategories = () => categories

export const addProduct = (product: Omit<Product, "id">) => {
  const newProduct = { ...product, id: products.length + 1 }
  products.push(newProduct)
  return newProduct
}

export const updateProduct = (id: number, updates: Partial<Product>) => {
  const index = products.findIndex((p) => p.id === id)
  if (index !== -1) {
    products[index] = { ...products[index], ...updates }
    return products[index]
  }
  return null
}

export const deleteProduct = (id: number) => {
  const index = products.findIndex((p) => p.id === id)
  if (index !== -1) {
    const [deletedProduct] = products.splice(index, 1)
    return deletedProduct
  }
  return null
}

