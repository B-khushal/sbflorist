"use client"

import Link from "next/link"
import { ShoppingCart, User, LogOut } from "lucide-react"
import { useSession, signOut } from "next-auth/react"
import { Button } from "@/components/ui/button"

const Header = () => {
  const { data: session } = useSession()

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="text-2xl font-bold text-pink-600">
          Blooming Blossoms
        </Link>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Link href="/products" className="text-gray-600 hover:text-pink-600">
                Shop
              </Link>
            </li>
            <li>
              <Link href="/about" className="text-gray-600 hover:text-pink-600">
                About
              </Link>
            </li>
            <li>
              <Link href="/contact" className="text-gray-600 hover:text-pink-600">
                Contact
              </Link>
            </li>
            {session?.user?.role === "admin" && (
              <li>
                <Link href="/admin" className="text-gray-600 hover:text-pink-600">
                  Admin
                </Link>
              </li>
            )}
          </ul>
        </nav>
        <div className="flex items-center space-x-4">
          <Link href="/cart" className="text-gray-600 hover:text-pink-600">
            <ShoppingCart />
          </Link>
          {session ? (
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">{session.user?.name}</span>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => signOut()}
                className="text-gray-600 hover:text-pink-600"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          ) : (
            <Link href="/auth/login" className="text-gray-600 hover:text-pink-600">
              <User />
            </Link>
          )}
        </div>
      </div>
    </header>
  )
}

export default Header

