"use client"

import type React from "react"
import { useCart } from "../contexts/CartContext"
import type { Product } from "../../lib/store"

const AddToCartButton: React.FC<{ product: Product }> = ({ product }) => {
  const { addToCart } = useCart()

  const handleAddToCart = () => {
    addToCart({ id: product.id, name: product.name, price: product.price, quantity: 1 })
  }

  return (
    <button
      onClick={handleAddToCart}
      className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 transition-colors"
    >
      Add to Cart
    </button>
  )
}

export default AddToCartButton

