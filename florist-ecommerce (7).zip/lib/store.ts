export interface Product {
  id: number
  name: string
  description: string
  price: number
  image: string
  categoryId: number
}

export interface Category {
  id: number
  name: string
}

export interface User {
  id: number
  email: string
  password: string
  name: string
  role: "USER" | "ADMIN"
}

export interface Order {
  id: number
  userId: number
  items: OrderItem[]
  total: number
  status: "PENDING" | "PROCESSING" | "SHIPPED" | "DELIVERED" | "CANCELLED"
  createdAt: Date
}

export interface OrderItem {
  productId: number
  quantity: number
  price: number
}

const products: Product[] = [
  {
    id: 1,
    name: "Spring Bouquet",
    description: "A beautiful bouquet of spring flowers",
    price: 49.99,
    image: "/images/spring-bouquet.jpg",
    categoryId: 1,
  },
  {
    id: 2,
    name: "Rose Arrangement",
    description: "An elegant arrangement of premium roses",
    price: 59.99,
    image: "/images/rose-arrangement.jpg",
    categoryId: 2,
  },
  {
    id: 3,
    name: "Tulip Collection",
    description: "A colorful collection of fresh tulips",
    price: 39.99,
    image: "/images/tulip-collection.jpg",
    categoryId: 1,
  },
  {
    id: 4,
    name: "Orchid Plant",
    description: "A stunning orchid plant for your home",
    price: 34.99,
    image: "/images/orchid-plant.jpg",
    categoryId: 4,
  },
  {
    id: 5,
    name: "Sunflower Bouquet",
    description: "Bright and cheerful sunflower bouquet",
    price: 44.99,
    image: "/images/sunflower-bouquet.jpg",
    categoryId: 1,
  },
  {
    id: 6,
    name: "Lily Arrangement",
    description: "Elegant lily arrangement for any occasion",
    price: 54.99,
    image: "/images/lily-arrangement.jpg",
    categoryId: 2,
  },
]

const categories: Category[] = [
  { id: 1, name: "Bouquets" },
  { id: 2, name: "Arrangements" },
  { id: 3, name: "Single Flowers" },
  { id: 4, name: "Plants" },
]

const users: User[] = [
  { id: 1, email: "admin@example.com", password: "admin123", name: "Admin User", role: "ADMIN" },
  { id: 2, email: "user@example.com", password: "user123", name: "Regular User", role: "USER" },
]

const orders: Order[] = []

export const getProducts = () => products
export const getProduct = (id: number) => products.find((p) => p.id === id)
export const getCategories = () => categories
export const getCategory = (id: number) => categories.find((c) => c.id === id)
export const getUsers = () => users
export const getUser = (id: number) => users.find((u) => u.id === id)
export const getOrders = () => orders
export const getOrder = (id: number) => orders.find((o) => o.id === id)

export const addProduct = (product: Omit<Product, "id">) => {
  const newProduct = { ...product, id: products.length + 1 }
  products.push(newProduct)
  return newProduct
}

export const updateProduct = (id: number, updates: Partial<Product>) => {
  const index = products.findIndex((p) => p.id === id)
  if (index !== -1) {
    products[index] = { ...products[index], ...updates }
    return products[index]
  }
  return null
}

export const deleteProduct = (id: number) => {
  const index = products.findIndex((p) => p.id === id)
  if (index !== -1) {
    const [deletedProduct] = products.splice(index, 1)
    return deletedProduct
  }
  return null
}

export const addOrder = (order: Omit<Order, "id" | "createdAt">) => {
  const newOrder = { ...order, id: orders.length + 1, createdAt: new Date() }
  orders.push(newOrder)
  return newOrder
}

export const updateOrderStatus = (id: number, status: Order["status"]) => {
  const order = orders.find((o) => o.id === id)
  if (order) {
    order.status = status
    return order
  }
  return null
}

